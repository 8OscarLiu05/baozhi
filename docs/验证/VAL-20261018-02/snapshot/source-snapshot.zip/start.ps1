param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$runtimePython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if (-not (Test-Path -LiteralPath $runtimePython)) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCommand) { throw 'Python 3.11 or newer is required.' }
    $runtimePython = $pythonCommand.Source
}
$projectPort = if ($env:BAOZHI_PORT) { $env:BAOZHI_PORT } else { '8765' }
$projectEnv = Join-Path $projectRoot '.env'
if ((Test-Path -LiteralPath $projectEnv) -and -not $env:BAOZHI_PORT) {
    foreach ($configLine in Get-Content -LiteralPath $projectEnv) {
        if ($configLine -match '^\s*BAOZHI_PORT\s*=\s*(\d+)\s*$') { $projectPort = $Matches[1] }
    }
}
$requiredBuild = 'REQ010-20261007'
$alreadyRunning = $false
$selectedPort = $null
# Keep existing processes intact. Reuse this build or select a free local port.
foreach ($candidatePort in ([int]$projectPort..([Math]::Min([int]$projectPort + 9, 65535)))) {
    $candidateUrl = "http://127.0.0.1:$candidatePort"
    try {
        $health = Invoke-RestMethod "$candidateUrl/api/health" -TimeoutSec 1
        if ($health.ok -and $health.local_only -and $health.version -eq '0.3.0' -and $health.build -eq $requiredBuild) {
            $alreadyRunning = $true; $selectedPort = $candidatePort; break
        }
    } catch { }
    $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $candidatePort)
    try { $probe.Start(); $selectedPort = $candidatePort; break } catch { } finally { $probe.Stop() }
}
if ($null -eq $selectedPort) { throw 'No free local port found. Close the previous Baozhi instance and retry.' }
$projectPort = $selectedPort
$projectUrl = "http://127.0.0.1:$projectPort"
if (-not $alreadyRunning) {
    $dataDir = Join-Path $projectRoot 'data'
    New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
    $process = Start-Process -FilePath $runtimePython -ArgumentList @('-X','utf8','app.py','--port',"$projectPort") -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $dataDir 'server.log') -RedirectStandardError (Join-Path $dataDir 'server-error.log')
    $ready = $false
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 250
        if ($process.HasExited) { throw 'Service failed to start. See data/server-error.log.' }
        try { $health = Invoke-RestMethod "$projectUrl/api/health" -TimeoutSec 1; if ($health.ok -and $health.local_only -and $health.version -eq '0.3.0' -and $health.build -eq $requiredBuild) { $ready = $true; break } } catch { }
    }
    if (-not $ready) { throw 'Service is not ready. See data/server-error.log.' }
    Set-Content -LiteralPath (Join-Path $dataDir 'server.pid') -Value $process.Id -Encoding ascii
}
Set-Content -LiteralPath (Join-Path $projectRoot 'data/server.url') -Value $projectUrl -Encoding ascii
Write-Output "Baozhi is running at $projectUrl"
if (-not $NoBrowser) { Start-Process $projectUrl }
