# 保溯

保溯是比赛用的本机保险智能体中台 Demo。展业、客户自助和电话中心共用条款知识、岗位授权、调用留存和人工复核。客户、保单和公司上下文均为虚构数据；公开条款只用于核对，不构成核保或赔付结论。

## 启动

Windows 下双击 `启动保智协同.cmd`。启动器会选择本机端口、复用同一版本服务并打开浏览器，不受 PowerShell 脚本执行策略限制。

也可以在项目目录执行：

```powershell
python -X utf8 launch.py
```

启动地址会写入 `data/server.url`。默认首页先显示开场页，点击“开始”进入展示页，再进入展业、客户自助、电话中心或平台端。

运行要求：Python 3.11 或更新版本。程序运行时只使用 Python 标准库；浏览器回归脚本另需项目现有的 Playwright/Node 环境。

## 模型配置

千问通过 OpenAI 兼容接口接入。本机 `.env` 使用以下变量，密钥不要写进文档、截图或提交包：

```text
BAOZHI_MODEL_URL=兼容接口地址
BAOZHI_MODEL=模型名称
BAOZHI_API_KEY=本机密钥
BAOZHI_ENABLE_THINKING=true 或 false
BAOZHI_PORT=8765
```

普通咨询和部分岗位方法题会调用模型。专业条款查询为零次模型调用。具体产品字段命中时最终答案可以直接使用字段模板，即使模型被调用也不一定采用模型正文。

## 当前范围

- 程序版本：`0.15.0`
- 构建：`REQ061-20261017`
- 三个入口是本机网页演示，没有接入真实展业 APP、微信、电话、录音、核保、出单或理赔支付系统。
- `data/baozhi.sqlite3` 是演示数据库，不得写入真实个人资料。
- 历史测试、开发集和公开小样本不等同于独立保险专业验证。

## 验证

运行 Python 自动化测试：

```powershell
python -m unittest discover -s tests -v
```

当前固定验证批次为 [`VAL-20261017-01`](docs/验证/VAL-20261017-01/测试方案.md)。该目录把功能流程、条款质量、异常处理和追溯复核分开记录。未完成人工条款复核前，不计算条款准确率。

冻结或核对批次快照：

```powershell
python tools/freeze_validation_batch.py
```

项目口径见 `PROJECT.md`，每次变更见 `ITERATIONS.md`，数据处理路径见 `保溯中台-数据处理与整合流程说明.md`。
